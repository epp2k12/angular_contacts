require('./angular-sanitize');
module.exports = 'ngSanitize';
